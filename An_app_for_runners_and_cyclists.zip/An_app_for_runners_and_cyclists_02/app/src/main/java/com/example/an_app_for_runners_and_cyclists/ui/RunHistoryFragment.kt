package com.example.an_app_for_runners_and_cyclists.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.an_app_for_runners_and_cyclists.adapter.RunMonthAdapter
import com.example.an_app_for_runners_and_cyclists.adapter.RunMonthItem
import com.example.an_app_for_runners_and_cyclists.databinding.FragmentRunHistoryBinding
import com.example.an_app_for_runners_and_cyclists.viewmodel.RunHistoryViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

@AndroidEntryPoint
class RunHistoryFragment : Fragment() {

    private var _binding: FragmentRunHistoryBinding? = null
    private val binding get() = _binding!!
    private val runHistoryViewModel: RunHistoryViewModel by viewModels()
    private lateinit var runMonthAdapter: RunMonthAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentRunHistoryBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()
        observeRunHistory()
    }

    private fun setupRecyclerView() {
        runMonthAdapter = RunMonthAdapter { run ->
            // Навигация к деталям забега
            // val action = RunHistoryFragmentDirections.actionRunHistoryFragmentToRunDetailsFragment(run.id)
            // findNavController().navigate(action)
        }

        binding.rvRunHistory.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = runMonthAdapter
        }
    }

    private fun observeRunHistory() {
        lifecycleScope.launch {
            val userId = "current_user_id"
            runHistoryViewModel.getRunsGroupedByMonth(userId).collectLatest { groupedRuns ->
                val monthItems = groupedRuns.map { (month, runs) ->
                    RunMonthItem(
                        month = month,
                        totalRuns = runs.size,
                        runs = runs
                    )
                }
                runMonthAdapter.submitList(monthItems)
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}