package com.example.an_app_for_runners_and_cyclists.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.an_app_for_runners_and_cyclists.data.Runner
import com.example.an_app_for_runners_and_cyclists.databinding.ItemRunnerBinding

class RunnersAdapter : ListAdapter<Runner, RunnersAdapter.RunnerViewHolder>(RunnerDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RunnerViewHolder {
        val binding = ItemRunnerBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return RunnerViewHolder(binding)
    }

    override fun onBindViewHolder(holder: RunnerViewHolder, position: Int) {
        val runner = getItem(position)
        holder.bind(runner)
    }

    inner class RunnerViewHolder(private val binding: ItemRunnerBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(runner: Runner) {
            binding.tvRunnerName.text = runner.name
            binding.tvRunnerAddress.text = runner.address
            binding.tvRunnerStats.text = runner.stats
        }
    }
}

class RunnerDiffCallback : DiffUtil.ItemCallback<Runner>() {
    override fun areItemsTheSame(oldItem: Runner, newItem: Runner): Boolean {
        return oldItem.name == newItem.name
    }

    override fun areContentsTheSame(oldItem: Runner, newItem: Runner): Boolean {
        return oldItem == newItem
    }
}