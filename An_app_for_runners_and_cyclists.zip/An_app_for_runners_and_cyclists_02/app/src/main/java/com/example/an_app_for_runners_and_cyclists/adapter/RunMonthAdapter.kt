package com.example.an_app_for_runners_and_cyclists.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.an_app_for_runners_and_cyclists.data.Run
import com.example.an_app_for_runners_and_cyclists.databinding.ItemRunMonthBinding
import com.example.an_app_for_runners_and_cyclists.utils.FormatUtils

class RunMonthAdapter(
    private val onRunClick: (Run) -> Unit
) : ListAdapter<RunMonthItem, RunMonthAdapter.RunMonthViewHolder>(RunMonthDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RunMonthViewHolder {
        val binding = ItemRunMonthBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return RunMonthViewHolder(binding, onRunClick)
    }

    override fun onBindViewHolder(holder: RunMonthViewHolder, position: Int) {
        val monthItem = getItem(position)
        holder.bind(monthItem)
    }

    class RunMonthViewHolder(
        private val binding: ItemRunMonthBinding,
        private val onRunClick: (Run) -> Unit
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(monthItem: RunMonthItem) {
            binding.tvMonth.text = monthItem.month
            binding.tvMonthStats.text = "${monthItem.totalRuns} Runs"

            // Настройка адаптера для отдельных забегов
            val runAdapter = RunHistoryAdapter(onRunClick)
            binding.rvRuns.adapter = runAdapter
            runAdapter.submitList(monthItem.runs)
        }
    }
}

class RunMonthDiffCallback : DiffUtil.ItemCallback<RunMonthItem>() {
    override fun areItemsTheSame(oldItem: RunMonthItem, newItem: RunMonthItem): Boolean {
        return oldItem.month == newItem.month
    }

    override fun areContentsTheSame(oldItem: RunMonthItem, newItem: RunMonthItem): Boolean {
        return oldItem == newItem
    }
}

data class RunMonthItem(
    val month: String,
    val totalRuns: Int,
    val runs: List<Run>
)