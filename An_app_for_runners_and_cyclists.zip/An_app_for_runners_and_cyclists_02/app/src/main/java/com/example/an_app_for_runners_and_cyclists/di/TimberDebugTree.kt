package com.example.an_app_for_runners_and_cyclists.di

import android.util.Log
import timber.log.Timber

class TimberDebugTree : Timber.DebugTree() {
    override fun createStackElementTag(element: StackTraceElement): String {
        return "RunnersApp:${super.createStackElementTag(element)}:${element.lineNumber}"
    }
}