package com.example.an_app_for_runners_and_cyclists.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.*

@Entity(tableName = "run_points")
data class RunPoint(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val runId: String,
    val timestamp: Date,
    val latitude: Double,
    val longitude: Double,
    val heartRate: Int? = null,
    val speed: Double = 0.0
)