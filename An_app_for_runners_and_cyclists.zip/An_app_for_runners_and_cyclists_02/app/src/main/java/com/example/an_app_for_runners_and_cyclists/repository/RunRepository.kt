package com.example.an_app_for_runners_and_cyclists.repository

import com.example.an_app_for_runners_and_cyclists.data.Run
import com.example.an_app_for_runners_and_cyclists.data.RunDao
import com.example.an_app_for_runners_and_cyclists.data.RunPoint
import com.example.an_app_for_runners_and_cyclists.data.RunPointDao
import com.example.an_app_for_runners_and_cyclists.data.User
import com.example.an_app_for_runners_and_cyclists.data.UserDao
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import timber.log.Timber

class RunRepository(
    private val runDao: RunDao,
    private val userDao: UserDao,
    private val runPointDao: RunPointDao
) {

    // User operations
    suspend fun getUserByEmail(email: String): User? = try {
        userDao.getUserByEmail(email)
    } catch (e: Exception) {
        Timber.e(e, "Error getting user by email: $email")
        null
    }

    suspend fun createUser(user: User) = try {
        userDao.insertUser(user)
    } catch (e: Exception) {
        Timber.e(e, "Error creating user: ${user.email}")
        throw e
    }

    suspend fun updateUser(user: User) = try {
        userDao.updateUser(user)
    } catch (e: Exception) {
        Timber.e(e, "Error updating user: ${user.email}")
        throw e
    }

    // Run operations
    fun getRunsByUser(userId: String): Flow<List<Run>> =
        runDao.getRunsByUser(userId)
            .catch { e ->
                Timber.e(e, "Error getting runs for user: $userId")
                emit(emptyList())
            }

    suspend fun getRunById(runId: String): Run? = try {
        runDao.getRunById(runId)
    } catch (e: Exception) {
        Timber.e(e, "Error getting run by id: $runId")
        null
    }

    fun getRunsByMonth(userId: String, monthYear: String): Flow<List<Run>> =
        runDao.getRunsByMonth(userId, monthYear)
            .catch { e ->
                Timber.e(e, "Error getting runs for month: $monthYear")
                emit(emptyList())
            }

    suspend fun saveRun(run: Run) = try {
        runDao.insertRun(run)
    } catch (e: Exception) {
        Timber.e(e, "Error saving run: ${run.id}")
        throw e
    }

    suspend fun updateRun(run: Run) = try {
        runDao.updateRun(run)
    } catch (e: Exception) {
        Timber.e(e, "Error updating run: ${run.id}")
        throw e
    }

    // Run points operations
    fun getRunPoints(runId: String): Flow<List<RunPoint>> =
        runPointDao.getRunPoints(runId)
            .catch { e ->
                Timber.e(e, "Error getting run points for run: $runId")
                emit(emptyList())
            }

    suspend fun saveRunPoints(points: List<RunPoint>) = try {
        runPointDao.insertAllRunPoints(points)
    } catch (e: Exception) {
        Timber.e(e, "Error saving run points")
        throw e
    }
}