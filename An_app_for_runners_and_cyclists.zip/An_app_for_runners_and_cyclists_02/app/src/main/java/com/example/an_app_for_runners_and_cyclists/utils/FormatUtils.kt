package com.example.an_app_for_runners_and_cyclists.utils

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

object FormatUtils {

    fun formatDuration(milliseconds: Long): String {
        val hours = TimeUnit.MILLISECONDS.toHours(milliseconds)
        val minutes = TimeUnit.MILLISECONDS.toMinutes(milliseconds) % 60
        val seconds = TimeUnit.MILLISECONDS.toSeconds(milliseconds) % 60

        return if (hours > 0) {
            String.format("%02d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format("%02d:%02d", minutes, seconds)
        }
    }

    fun formatDate(date: Date): String {
        val dateFormat = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault())
        return dateFormat.format(date)
    }

    fun formatShortDate(date: Date): String {
        val dateFormat = SimpleDateFormat("EEE dd, HH:mm", Locale.getDefault())
        return dateFormat.format(date)
    }

    fun calculateCaloriesBurned(distance: Double, weight: Double?): Double {
        // Упрощенная формула расчета калорий
        return distance * (weight ?: 70.0) * 1.036
    }

    fun formatDistance(km: Double): String {
        return String.format(Locale.getDefault(), "%.2f km", km)
    }

    fun formatCalories(calories: Double): String {
        return String.format(Locale.getDefault(), "%.0f", calories)
    }
}