package com.example.an_app_for_runners_and_cyclists.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class User(
    @PrimaryKey
    val email: String,
    val username: String? = null,
    val fullName: String,
    val address: String = "",
    val height: Int? = null,
    val weight: Int? = null,
    val runningReason: String? = null,
    val signUpMethod: String = "Email"
)