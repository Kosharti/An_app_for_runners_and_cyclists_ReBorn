package com.example.an_app_for_runners_and_cyclists.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverters
import java.util.*

@Entity(tableName = "runs")
data class Run(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val userId: String,
    val date: Date,
    val duration: Long, // in seconds
    val distance: Double, // in km
    val calories: Double,
    val weather: String? = null,
    val temperature: Int? = null,
    val averageBPM: Int? = null,
    val location: String? = null
)