package com.example.an_app_for_runners_and_cyclists.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import com.example.an_app_for_runners_and_cyclists.databinding.FragmentProfileBinding
import com.example.an_app_for_runners_and_cyclists.utils.FormatUtils
import com.example.an_app_for_runners_and_cyclists.viewmodel.AuthViewModel
import com.example.an_app_for_runners_and_cyclists.viewmodel.RunHistoryViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

@AndroidEntryPoint
class ProfileFragment : Fragment() {

    private var _binding: FragmentProfileBinding? = null
    private val binding get() = _binding!!
    private val authViewModel: AuthViewModel by viewModels()
    private val runHistoryViewModel: RunHistoryViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentProfileBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupClickListeners()
        observeUserData()
        observeTotalStats()
    }

    private fun setupClickListeners() {
        binding.btnSaveProfile.setOnClickListener {
            saveProfile()
        }
    }

    private fun saveProfile() {
        val username = binding.etUsername.text?.toString()
        val email = binding.etEmail.text?.toString()
        val height = binding.etHeight.text?.toString()?.toIntOrNull()
        val weight = binding.etWeight.text?.toString()?.toIntOrNull()
        val runningReason = binding.etRunningReason.text?.toString()

        lifecycleScope.launch {
            val currentUser = authViewModel.currentUser.value
            currentUser?.let { user ->
                val updatedUser = user.copy(
                    username = username,
                    email = email ?: user.email,
                    height = height,
                    weight = weight,
                    runningReason = runningReason
                )
                authViewModel.updateProfile(updatedUser)
            }
        }
    }

    private fun observeUserData() {
        lifecycleScope.launch {
            authViewModel.currentUser.collectLatest { user ->
                user?.let {
                    binding.tvFullName.text = it.fullName
                    binding.tvAddress.text = it.address
                    binding.etUsername.setText(it.username ?: "")
                    binding.etEmail.setText(it.email)
                    binding.etHeight.setText(it.height?.toString() ?: "")
                    binding.etWeight.setText(it.weight?.toString() ?: "")
                    binding.etRunningReason.setText(it.runningReason ?: "")
                }
            }
        }
    }

    private fun observeTotalStats() {
        lifecycleScope.launch {
            val userId = "current_user_id"
            runHistoryViewModel.getTotalStats(userId).collectLatest { (distance, duration, calories) ->
                binding.tvDistance.text = FormatUtils.formatDistance(distance)
                binding.tvDuration.text = FormatUtils.formatDuration(duration)
                binding.tvCalories.text = "${FormatUtils.formatCalories(calories)} kCal"
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}