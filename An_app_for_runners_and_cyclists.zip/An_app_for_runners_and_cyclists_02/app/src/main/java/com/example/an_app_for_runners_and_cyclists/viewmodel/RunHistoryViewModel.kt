package com.example.an_app_for_runners_and_cyclists.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.an_app_for_runners_and_cyclists.data.Run
import com.example.an_app_for_runners_and_cyclists.repository.RunRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

class RunHistoryViewModel @Inject constructor(
    private val repository: RunRepository
) : ViewModel() {

    fun getRunsGroupedByMonth(userId: String): Flow<Map<String, List<Run>>> {
        return repository.getRunsByUser(userId).map { runs ->
            runs.groupBy { run ->
                // Используем правильный формат для Room запросов
                SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(run.date)
            }.mapKeys { (monthKey, runs) ->
                // Преобразуем обратно в красивый формат для отображения
                val date = SimpleDateFormat("yyyy-MM", Locale.getDefault()).parse(monthKey)
                SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(date ?: Date())
            }
        }
    }

    fun getTotalStats(userId: String): Flow<Triple<Double, Long, Double>> {
        return repository.getRunsByUser(userId).map { runs ->
            val totalDistance = runs.sumOf { it.distance }
            val totalDuration = runs.sumOf { it.duration }
            val totalCalories = runs.sumOf { it.calories }
            Triple(totalDistance, totalDuration, totalCalories)
        }
    }

    suspend fun getRunById(runId: String): Run? {
        return repository.getRunById(runId)
    }
}