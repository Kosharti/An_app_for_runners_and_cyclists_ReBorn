package com.example.an_app_for_runners_and_cyclists.data

data class Runner(
    val name: String,
    val address: String,
    val stats: String
)