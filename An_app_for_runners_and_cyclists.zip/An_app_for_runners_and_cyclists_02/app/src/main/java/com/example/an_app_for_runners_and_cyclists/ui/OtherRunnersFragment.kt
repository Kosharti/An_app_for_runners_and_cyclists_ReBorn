package com.example.an_app_for_runners_and_cyclists.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.an_app_for_runners_and_cyclists.adapter.RunnersAdapter
import com.example.an_app_for_runners_and_cyclists.data.Runner
import com.example.an_app_for_runners_and_cyclists.databinding.FragmentOtherRunnersBinding

class OtherRunnersFragment : Fragment() {

    private var _binding: FragmentOtherRunnersBinding? = null
    private val binding get() = _binding!!
    private lateinit var runnersAdapter: RunnersAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentOtherRunnersBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupRecyclerView()
        loadRunners()
    }

    private fun setupRecyclerView() {
        runnersAdapter = RunnersAdapter()
        binding.rvOtherRunners.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = runnersAdapter
        }
    }

    private fun loadRunners() {
        val runners = listOf(
            Runner(
                name = "Bobby A. Munson",
                address = "4855 Plainfield Avenue\nSyracuse, NY 13202",
                stats = "15 km  02:50:51  1540 kCal"
            ),
            Runner(
                name = "Allison Hardy",
                address = "1233 Hamilton Avenue\nBoston",
                stats = "15 km  02:50:51  1540 kCal"
            ),
            Runner(
                name = "Jack Adams",
                address = "1222 Sundown Road\nLos Angeles",
                stats = "15 km  02:50:51  1540 kCal"
            ),
            Runner(
                name = "Frank Bailey",
                address = "1009 Railroad Lane\nDenver",
                stats = "15 km  02:50:51  1540 kCal"
            ),
            Runner(
                name = "Victor Austin",
                address = "4855 Plainfield Avenue\nSyracuse, NY 13202",
                stats = "15 km  02:50:51  1540 kCal"
            )
        )

        runnersAdapter.submitList(runners)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}