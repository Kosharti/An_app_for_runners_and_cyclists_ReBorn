package com.example.an_app_for_runners_and_cyclists.di

import android.app.Application
import dagger.hilt.android.HiltAndroidApp
import timber.log.Timber

@HiltAndroidApp
class RunnersExchangeApplication : Application() {

    override fun onCreate() {
        super.onCreate()

        // Инициализация Timber
        val isDebug = applicationContext.applicationInfo != null &&
                applicationContext.applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE != 0

        if (isDebug) {
            Timber.plant(Timber.DebugTree())
        }

        Timber.d("RunnersExchangeApplication initialized")
    }
}