package com.example.an_app_for_runners_and_cyclists.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.an_app_for_runners_and_cyclists.data.User
import com.example.an_app_for_runners_and_cyclists.repository.RunRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

class AuthViewModel @Inject constructor(
    private val repository: RunRepository
) : ViewModel() {

    private val _currentUser = MutableStateFlow<User?>(null)
    val currentUser: StateFlow<User?> = _currentUser

    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    fun login(email: String, password: String) = viewModelScope.launch {
        _isLoading.value = true
        _authError.value = null

        try {
            val user = repository.getUserByEmail(email) ?: User(
                email = email,
                fullName = "Bobby A. Munson",
                address = "4865 Plainfield Avenue\nSyracuse, NY 13022"
            )
            _currentUser.value = user
        } catch (e: Exception) {
            _authError.value = "Login failed: ${e.message}"
        } finally {
            _isLoading.value = false
        }
    }

    fun signUp(email: String, password: String, fullName: String) = viewModelScope.launch {
        _isLoading.value = true
        _authError.value = null

        try {
            // Проверяем, не существует ли уже пользователь
            val existingUser = repository.getUserByEmail(email)
            if (existingUser != null) {
                _authError.value = "User with this email already exists"
                return@launch
            }

            val user = User(
                email = email,
                fullName = fullName,
                address = ""
            )
            repository.createUser(user)
            _currentUser.value = user
        } catch (e: Exception) {
            _authError.value = "Registration failed: ${e.message}"
        } finally {
            _isLoading.value = false
        }
    }

    fun updateProfile(user: User) = viewModelScope.launch {
        try {
            repository.updateUser(user)
            _currentUser.value = user
        } catch (e: Exception) {
            _authError.value = "Profile update failed: ${e.message}"
        }
    }

    fun clearError() {
        _authError.value = null
    }
}