package com.example.an_app_for_runners_and_cyclists.service

import android.content.Context
import android.content.Intent
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData

class LocationManager(private val context: Context) {

    private val _isTracking = MutableLiveData(false)
    val isTracking: LiveData<Boolean> = _isTracking

    fun startLocationTracking() {
        val intent = Intent(context, LocationService::class.java).apply {
            action = LocationService.ACTION_START
        }

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            context.startForegroundService(intent)
        } else {
            context.startService(intent)
        }

        _isTracking.value = true
    }

    fun stopLocationTracking() {
        val intent = Intent(context, LocationService::class.java).apply {
            action = LocationService.ACTION_STOP
        }
        context.startService(intent)
        _isTracking.value = false
    }
}