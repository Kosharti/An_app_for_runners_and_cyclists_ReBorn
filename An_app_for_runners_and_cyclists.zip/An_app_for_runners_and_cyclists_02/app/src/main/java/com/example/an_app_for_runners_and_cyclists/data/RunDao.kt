package com.example.an_app_for_runners_and_cyclists.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow
import java.util.*

@Dao
interface RunDao {
    @Query("SELECT * FROM runs WHERE userId = :userId ORDER BY date DESC")
    fun getRunsByUser(userId: String): Flow<List<Run>>

    @Query("SELECT * FROM runs WHERE id = :runId")
    suspend fun getRunById(runId: String): Run?

    // Исправленный запрос для группировки по месяцам
    @Query("""
        SELECT * FROM runs 
        WHERE userId = :userId 
        AND strftime('%Y-%m', datetime(date / 1000, 'unixepoch')) = :monthYear 
        ORDER BY date DESC
    """)
    fun getRunsByMonth(userId: String, monthYear: String): Flow<List<Run>>

    @Insert
    suspend fun insertRun(run: Run)

    @Update
    suspend fun updateRun(run: Run)

    @Delete
    suspend fun deleteRun(run: Run)
}

@Dao
interface UserDao {
    @Query("SELECT * FROM users WHERE email = :email")
    suspend fun getUserByEmail(email: String): User?

    @Insert
    suspend fun insertUser(user: User)

    @Update
    suspend fun updateUser(user: User)

    @Query("DELETE FROM users WHERE email = :email")
    suspend fun deleteUser(email: String)
}

@Dao
interface RunPointDao {
    @Query("SELECT * FROM run_points WHERE runId = :runId ORDER BY timestamp")
    fun getRunPoints(runId: String): Flow<List<RunPoint>>

    @Insert
    suspend fun insertRunPoint(point: RunPoint)

    @Insert
    suspend fun insertAllRunPoints(points: List<RunPoint>)

    @Query("DELETE FROM run_points WHERE runId = :runId")
    suspend fun deleteRunPoints(runId: String)
}