package com.example.an_app_for_runners_and_cyclists.ui

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.example.an_app_for_runners_and_cyclists.R
import com.example.an_app_for_runners_and_cyclists.databinding.FragmentSignUpBinding
import com.example.an_app_for_runners_and_cyclists.viewmodel.AuthViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

@AndroidEntryPoint
class SignUpFragment : Fragment() {

    private var _binding: FragmentSignUpBinding? = null
    private val binding get() = _binding!!
    private val authViewModel: AuthViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSignUpBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupClickListeners()
        observeAuthState()
    }

    private fun setupClickListeners() {
        binding.btnSubmit.setOnClickListener {
            signUp()
        }
    }

    private fun observeAuthState() {
        lifecycleScope.launch {
            authViewModel.currentUser.collectLatest { user ->
                user?.let {
                    findNavController().navigate(R.id.action_signInFragment_to_main_nav_graph)
                }
            }
        }

        lifecycleScope.launch {
            authViewModel.authError.collectLatest { error ->
                error?.let {
                    showError(error)
                }
            }
        }

        lifecycleScope.launch {
            authViewModel.isLoading.collectLatest { isLoading ->
                binding.btnSubmit.isEnabled = !isLoading
                binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
            }
        }
    }

    private fun signUp() {
        val email = binding.etEmail.text?.toString()
        val password = binding.etPassword.text?.toString()
        val fullName = binding.etFullName.text?.toString()

        if (email.isNullOrEmpty() || password.isNullOrEmpty() || fullName.isNullOrEmpty()) {
            showError("Please fill all fields")
            return
        }

        if (!isValidEmail(email)) {
            showError("Please enter a valid email address")
            return
        }

        if (password.length < 6) {
            showError("Password should be at least 6 characters")
            return
        }

        authViewModel.signUp(email, password, fullName)
    }

    private fun isValidEmail(email: String): Boolean {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }

    private fun showError(message: String) {
        android.app.AlertDialog.Builder(requireContext())
            .setTitle("Error")
            .setMessage(message)
            .setPositiveButton("OK") { dialog, _ ->
                dialog.dismiss()
                authViewModel.clearError()
            }
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}