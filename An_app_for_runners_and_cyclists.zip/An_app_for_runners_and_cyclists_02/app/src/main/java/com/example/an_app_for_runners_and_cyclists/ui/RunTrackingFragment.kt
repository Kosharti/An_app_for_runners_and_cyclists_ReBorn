package com.example.an_app_for_runners_and_cyclists.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.CountDownTimer
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import com.example.an_app_for_runners_and_cyclists.databinding.FragmentRunTrackingBinding
import com.example.an_app_for_runners_and_cyclists.service.LocationManager
import com.example.an_app_for_runners_and_cyclists.utils.FormatUtils
import com.example.an_app_for_runners_and_cyclists.utils.PermissionUtils
import com.example.an_app_for_runners_and_cyclists.viewmodel.RunTrackingViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class RunTrackingFragment : Fragment() {

    private var _binding: FragmentRunTrackingBinding? = null
    private val binding get() = _binding!!
    private val runTrackingViewModel: RunTrackingViewModel by viewModels()

    @Inject
    lateinit var locationManager: LocationManager

    private var timer: CountDownTimer? = null
    private var startTime: Long = 0L

    // Регистрация для запроса разрешений
    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val allGranted = permissions.values.all { it }
        if (allGranted) {
            startRunWithPermissions()
        } else {
            // Показать сообщение, что разрешения необходимы
            showPermissionDeniedMessage()
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentRunTrackingBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupClickListeners()
        observeRunState()
    }

    private fun setupClickListeners() {
        binding.btnStartRun.setOnClickListener {
            checkPermissionsAndStartRun()
        }

        binding.btnStopRun.setOnClickListener {
            stopRun()
        }
    }

    private fun checkPermissionsAndStartRun() {
        if (PermissionUtils.hasLocationPermissions(requireContext())) {
            startRunWithPermissions()
        } else {
            requestLocationPermissions()
        }
    }

    private fun requestLocationPermissions() {
        requestPermissionLauncher.launch(
            arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            )
        )
    }

    private fun startRunWithPermissions() {
        val userId = "current_user_id" // В реальном приложении получать из Auth
        runTrackingViewModel.startRun(userId)
        locationManager.startLocationTracking()
        startTime = System.currentTimeMillis()

        timer = object : CountDownTimer(Long.MAX_VALUE, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                val elapsed = System.currentTimeMillis() - startTime
                runTrackingViewModel.updateElapsedTime(elapsed)

                // Обновляем UI
                binding.tvDuration.text = FormatUtils.formatDuration(elapsed)

                // Mock данные для дистанции и калорий (в реальном приложении получать с датчиков)
                val distance = (elapsed / 1000) * 0.003 // примерная скорость 3 м/с
                val calories = distance * 60 // примерный расчет калорий

                binding.tvDistance.text = String.format("%.2f", distance)
                binding.tvCalories.text = String.format("%.0f", calories)
            }

            override fun onFinish() {}
        }.start()
    }

    private fun stopRun() {
        timer?.cancel()
        runTrackingViewModel.stopRun()
        locationManager.stopLocationTracking()

        // Сохраняем финальные данные
        val elapsed = System.currentTimeMillis() - startTime
        val distance = (elapsed / 1000) * 0.003
        val calories = distance * 60

        runTrackingViewModel.updateRunStats(
            duration = elapsed / 1000,
            distance = distance,
            calories = calories
        )
    }

    private fun observeRunState() {
        lifecycleScope.launch {
            runTrackingViewModel.isTracking.collectLatest { isTracking ->
                if (isTracking) {
                    binding.btnStartRun.visibility = View.GONE
                    binding.btnStopRun.visibility = View.VISIBLE
                } else {
                    binding.btnStartRun.visibility = View.VISIBLE
                    binding.btnStopRun.visibility = View.GONE
                }
            }
        }
    }

    private fun showPermissionDeniedMessage() {
        // Показать диалог или сообщение о необходимости разрешений
        android.app.AlertDialog.Builder(requireContext())
            .setTitle("Location Permission Required")
            .setMessage("This app needs location permissions to track your runs. Please grant the permissions in app settings.")
            .setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        timer?.cancel()
        _binding = null
    }
}