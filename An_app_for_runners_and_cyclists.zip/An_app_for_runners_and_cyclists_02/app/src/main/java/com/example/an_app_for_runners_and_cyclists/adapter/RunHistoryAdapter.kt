package com.example.an_app_for_runners_and_cyclists.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.an_app_for_runners_and_cyclists.data.Run
import com.example.an_app_for_runners_and_cyclists.databinding.ItemRunBinding
import com.example.an_app_for_runners_and_cyclists.utils.FormatUtils

class RunHistoryAdapter(
    private val onRunClick: (Run) -> Unit
) : ListAdapter<Run, RunHistoryAdapter.RunViewHolder>(RunDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RunViewHolder {
        val binding = ItemRunBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return RunViewHolder(binding)
    }

    override fun onBindViewHolder(holder: RunViewHolder, position: Int) {
        val run = getItem(position)
        holder.bind(run)
    }

    inner class RunViewHolder(private val binding: ItemRunBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(run: Run) {
            binding.tvDate.text = FormatUtils.formatShortDate(run.date)
            binding.tvStats.text = "${run.distance} km in ${FormatUtils.formatDuration(run.duration * 1000)}"
            binding.root.setOnClickListener { onRunClick(run) }
        }
    }
}

class RunDiffCallback : DiffUtil.ItemCallback<Run>() {
    override fun areItemsTheSame(oldItem: Run, newItem: Run): Boolean {
        return oldItem.id == newItem.id
    }

    override fun areContentsTheSame(oldItem: Run, newItem: Run): Boolean {
        return oldItem == newItem
    }
}