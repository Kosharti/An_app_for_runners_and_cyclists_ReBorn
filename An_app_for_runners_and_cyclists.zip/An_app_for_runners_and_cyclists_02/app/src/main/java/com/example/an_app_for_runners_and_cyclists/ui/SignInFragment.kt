package com.example.an_app_for_runners_and_cyclists.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.example.an_app_for_runners_and_cyclists.R
import com.example.an_app_for_runners_and_cyclists.databinding.FragmentSignInBinding
import com.example.an_app_for_runners_and_cyclists.viewmodel.AuthViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

@AndroidEntryPoint
class SignInFragment : Fragment() {

    private var _binding: FragmentSignInBinding? = null
    private val binding get() = _binding!!
    private val authViewModel: AuthViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSignInBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupClickListeners()
        observeAuthState()
    }

    private fun setupClickListeners() {
        binding.btnSignIn.setOnClickListener {
            signIn()
        }

        binding.btnGoToSignUp.setOnClickListener {
            findNavController().navigate(R.id.action_signInFragment_to_signUpFragment)
        }
    }

    private fun observeAuthState() {
        lifecycleScope.launch {
            authViewModel.currentUser.collectLatest { user ->
                user?.let {
                    findNavController().navigate(R.id.action_signInFragment_to_main_nav_graph)
                }
            }
        }

        lifecycleScope.launch {
            authViewModel.authError.collectLatest { error ->
                error?.let {
                    showError(error)
                }
            }
        }

        lifecycleScope.launch {
            authViewModel.isLoading.collectLatest { isLoading ->
                binding.btnSignIn.isEnabled = !isLoading
                binding.btnGoToSignUp.isEnabled = !isLoading
                binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
            }
        }
    }

    private fun signIn() {
        val email = binding.etEmail.text?.toString()
        val password = binding.etPassword.text?.toString()

        if (email.isNullOrEmpty() || password.isNullOrEmpty()) {
            showError("Please enter both email and password")
            return
        }

        if (!isValidEmail(email)) {
            showError("Please enter a valid email address")
            return
        }

        authViewModel.login(email, password)
    }

    private fun isValidEmail(email: String): Boolean {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }

    private fun showError(message: String) {
        android.app.AlertDialog.Builder(requireContext())
            .setTitle("Error")
            .setMessage(message)
            .setPositiveButton("OK") { dialog, _ ->
                dialog.dismiss()
                authViewModel.clearError()
            }
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}