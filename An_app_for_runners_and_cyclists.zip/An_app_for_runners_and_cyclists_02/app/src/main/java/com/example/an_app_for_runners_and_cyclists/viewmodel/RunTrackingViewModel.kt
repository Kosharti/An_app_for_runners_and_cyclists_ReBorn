package com.example.an_app_for_runners_and_cyclists.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.an_app_for_runners_and_cyclists.data.Run
import com.example.an_app_for_runners_and_cyclists.repository.RunRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import timber.log.Timber
import java.util.*
import javax.inject.Inject

class RunTrackingViewModel @Inject constructor(
    private val repository: RunRepository
) : ViewModel() {

    private val _currentRun = MutableStateFlow<Run?>(null)
    val currentRun: StateFlow<Run?> = _currentRun

    private val _isTracking = MutableStateFlow(false)
    val isTracking: StateFlow<Boolean> = _isTracking

    private val _elapsedTime = MutableStateFlow(0L)
    val elapsedTime: StateFlow<Long> = _elapsedTime

    private val _trackingError = MutableStateFlow<String?>(null)
    val trackingError: StateFlow<String?> = _trackingError

    fun startRun(userId: String) = viewModelScope.launch {
        _trackingError.value = null
        try {
            val run = Run(
                userId = userId,
                date = Date(),
                duration = 0L,
                distance = 0.0,
                calories = 0.0,
                weather = "Sunny",
                temperature = 25,
                averageBPM = 75,
                location = "Current Location"
            )
            repository.saveRun(run)
            _currentRun.value = run
            _isTracking.value = true
            Timber.d("Run started: ${run.id}")
        } catch (e: Exception) {
            _trackingError.value = "Failed to start run: ${e.message}"
            Timber.e(e, "Error starting run")
        }
    }

    fun stopRun() {
        _isTracking.value = false
        Timber.d("Run stopped")
    }

    fun updateRunStats(duration: Long, distance: Double, calories: Double) = viewModelScope.launch {
        val current = _currentRun.value
        current?.let { run ->
            try {
                val updatedRun = run.copy(
                    duration = duration,
                    distance = distance,
                    calories = calories
                )
                repository.updateRun(updatedRun)
                _currentRun.value = updatedRun
                Timber.d("Run stats updated: $duration s, $distance km, $calories cal")
            } catch (e: Exception) {
                _trackingError.value = "Failed to save run: ${e.message}"
                Timber.e(e, "Error updating run stats")
            }
        }
    }

    fun updateElapsedTime(time: Long) {
        _elapsedTime.value = time
    }

    fun clearError() {
        _trackingError.value = null
    }
}