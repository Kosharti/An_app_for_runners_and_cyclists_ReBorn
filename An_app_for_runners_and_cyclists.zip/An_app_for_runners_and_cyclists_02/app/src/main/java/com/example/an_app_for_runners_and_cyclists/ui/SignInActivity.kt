package com.example.an_app_for_runners_and_cyclists.ui

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.activity.viewModels
import androidx.lifecycle.lifecycleScope
import com.example.an_app_for_runners_and_cyclists.MainActivity
import com.example.an_app_for_runners_and_cyclists.databinding.ActivitySignInBinding
import com.example.an_app_for_runners_and_cyclists.viewmodel.AuthViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

@AndroidEntryPoint
class SignInActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySignInBinding
    private val authViewModel: AuthViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignInBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupClickListeners()
        observeAuthState()
    }

    private fun setupClickListeners() {
        binding.btnFacebookLogin.setOnClickListener {
            handleFacebookLogin()
        }

        // Добавляем кнопку в XML
        // binding.btnCreateAccount.setOnClickListener {
        //     navigateToSignUp()
        // }
    }

    private fun observeAuthState() {
        lifecycleScope.launch {
            authViewModel.currentUser.collectLatest { user ->
                user?.let {
                    startActivity(Intent(this@SignInActivity, MainActivity::class.java))
                    finish()
                }
            }
        }
    }

    private fun handleFacebookLogin() {
        authViewModel.login("mock@email.com", "password")
    }
}